package banco;

public class BancoSeguros implements QualquerBanco{

  public double saldoTotal(){
    return 1000;
  }

  public int numContas(){
    return 7;
  }

}